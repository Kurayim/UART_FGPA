#include <iostream>
#include <string>
#include <cstdlib>
#include <limits>
#include <Windows.h>
#include <fstream>
#include <vector>
#include <conio.h> 
#include <thread>

using namespace std;

bool isCtrlHPressed();
bool isCtrlOPressed();

int saveText(string entrance);
int Open_File();


vector<char> Analysis(string sentence);
string vectorToString(const vector<vector<char>>& entrance);

void moveCursor(int x, int y); 


int main() {
	vector<vector<char>> sentences;
	vector<int> line_len;
	string entrance;
	char c;

	int cursor_x = 0;
	int cursor_y = 0;
	cout << "-------------------------------------------------------------- \n Save(Ctrl+S) _ Open (Ctrl+O) \n-------------------------------------------------------------- \n";

	while (true) {

		vector<char> words;
		string text_file;

		c = _getch();

		if (c >= 32 && c <= 128) {
			entrance += c;
			cursor_x++;
			cout << c;
		}

		if (c == 8) {
			if (!entrance.empty()) {
				entrance.pop_back();
				cursor_x--;
			}
			cout << "\b \b";

		}


		
		if (!sentences.empty()) {
			text_file = vectorToString(sentences);
		}

		if (isCtrlHPressed()) {
			saveText(text_file);
			Sleep(10);
		}

		if (isCtrlOPressed()) {
			Open_File();
			Sleep(10);
		}

		if (c == -32 || c == 224) {
			c = _getch();
			if (c == 75 && cursor_x > 0) {
				cursor_x--;
				moveCursor(cursor_x, cursor_y+3);
			}
			else if (c == 77 && cursor_x < entrance.length()) {
				cursor_x++;
				moveCursor(cursor_x, cursor_y+3);
			}

			else if (c == 72 && cursor_y > 0) {
				if (!entrance.empty()) { // 
					if (cursor_y == sentences.size()) {
						sentences.push_back(vector<char>(entrance.begin(), entrance.end()));
						line_len.push_back(entrance.length());
					}
					else {
						sentences[cursor_y] = vector<char>(entrance.begin(), entrance.end());
						line_len[cursor_y] = entrance.length();
					}
				}

				cursor_y--;
				entrance = string(sentences[cursor_y].begin(), sentences[cursor_y].end());
				cursor_x = min(cursor_x, (int)entrance.length());

				moveCursor(cursor_x, cursor_y + 3);
			}
			else if (c == 80) { 

				if (cursor_y  < (int)sentences.size() -1 ) {  
					cursor_y++;
					entrance = string(sentences[cursor_y].begin(), sentences[cursor_y].end());
					cursor_x = min(cursor_x, (int)entrance.length());
				}

				moveCursor(cursor_x, cursor_y + 3);
			}
		}

		if (c == 13) {
			words = Analysis(entrance);
			sentences.push_back(words);
			line_len.push_back(entrance.length());
			cursor_y++;
			cursor_x = 0;
			entrance = "";
			cout << endl;

		}
		

	}



	return 0;
}



bool isCtrlHPressed() {
	return(GetAsyncKeyState(VK_CONTROL) & 0x8000 && (GetAsyncKeyState('S') & 0x8000));
}


bool isCtrlOPressed() {
	return(GetAsyncKeyState(VK_CONTROL) & 0x8000 && (GetAsyncKeyState('O') & 0x8000));
}





vector<char> Analysis(string sentence) {
	vector<char> words;

	for (char c : sentence) {
		words.push_back(c);
	}
	return words;
}



string vectorToString(const vector<vector<char>>& entrance) {
	string result;

	for (const auto& row : entrance) {
		for (char ch : row) {
			result += ch;
		}
		result += '\n';
	}

	return result;

}



int saveText(string entrance) {

	string File_name;

	system("cls");
	cout << "-------------------------------------------------------------- \n Save(Ctrl+S) _ Open (Ctrl+O) \n-------------------------------------------------------------- \n";

	cout << "Address of the desired text_file :";
	getline(cin, File_name);

	string address = "C:/Users/Crime-mo/Desktop/name_file/" + File_name + ".txt";
	ofstream outputFile(address);

	if (outputFile.is_open()) {

		outputFile << entrance;

		outputFile.close();


	}

	system("cls");
	cout << "-------------------------------------------------------------- \n Save(Ctrl+S) _ Open (Ctrl+O) \n-------------------------------------------------------------- \n";
	cout << entrance;

	return 0;


}




int Open_File() {

	string Folder_name;
	string File_name;
	string address;

	system("cls");
	cout << "-------------------------------------------------------------- \n Save(Ctrl+S) _ Open (Ctrl+O) \n-------------------------------------------------------------- \n";

	cout << "Enter Folder name :";
	getline(cin, Folder_name);
	cout << endl << "Enter Text_File name :";
	getline(cin, File_name);
	address = "C:/Users/Crime-mo/Desktop/" + Folder_name + "/" + File_name + ".txt";


	system("cls");

	ifstream file(address);

	if (!file) {
		cerr << "Error opening file" << endl;
		return 1;
	}

	char ch;
	cout << "-------------------------------------------------------------- \n Save(Ctrl+S) _ Open (Ctrl+O) \n-------------------------------------------------------------- \n";
	while (file.get(ch)) {
		if (ch == 8) {
			cout << endl;
		}
		cout << ch;
	}

	file.close();


}



void moveCursor(int x, int y) {
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD pos = { (SHORT)x, (SHORT)y };
	SetConsoleCursorPosition(hConsole, pos);
}